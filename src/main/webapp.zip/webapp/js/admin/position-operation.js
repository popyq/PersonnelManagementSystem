$(function () {

    // 新增职位
    var addPositionUrl = '/position/insertPosition'
    // 查看职位详情
    var queryPositionUrl = '/position/queryPositionById'
    // 修改职位信息url
    var editPositionUrl = '/position/editPositionById'

    var position_id = getQueryParam('positionId')
    console.log("position_id"+position_id)
    var is_edit = getQueryParam("edit")

    // 如果能从url获取到position_id,name 那么说明用户要么在进行查看,要么在进行编辑
    if (position_id){
        // 需要从后端获取对应的职位信息,并填充到页面上
        // 这个也是ajax请求 只不过直接指定post请求
        $.post(queryPositionUrl,{positionId:position_id},function (data) {
            // console.log(data)
            if (data.success){
                var position =data.data;
                $('#position-name').val(position.positionName)
                if (position.status === 1){
                    $('#status-on').attr('checked',true)
                    $('#status-off').removeAttr('checked')
                }else{
                    $('#status-off').attr('checked',true)
                    $('#status-on').removeAttr('checked')
                }
            }
        })
    }

    $('#status-on').click(function () {
        console.log('启用按钮被点击了~')
        $('#status-on').attr('checked',true)
        $('#status-off').removeAttr('checked')
    })

    $('#status-off').click(function () {
        console.log('禁用按钮被点击了~')
        $('#status-off').attr('checked',true)
        $('#status-on').removeAttr('checked')
    })

    $("#submit").click(function(){
        var position = {}
        // 需要名称,地址,状态
        position.positionName = $('#position-name').val();
        position.status = $('input[name="status"][checked]').val()
        if (is_edit){
            position.positionId = position_id
        }
        var formData = new FormData();
        // 之前学的表单数据提交可以理解成键值对  key(input标签的name属性),value就是input框的值
        formData.append("positionStr",JSON.stringify(position))
        $.ajax({
            url:is_edit ? editPositionUrl : addPositionUrl,
            type:'post',
            dataType:'json',
            cache : false,
            contentType:false,
            // processData: false,表示会不会序列化data里面的数据,默认是true
            processData: false,
            data:formData,
            success:function(data){
                console.log(data)
                if (data.success) {
                    lightyear.notify('操作成功~', 'success', 500, 'mdi mdi-emoticon-happy', 'top', 'center','/position/toList');
                }else {
                    lightyear.notify(data.errMsg, 'danger', 500, 'mdi mdi-emoticon-sad', 'top', 'center');
                }
            }
        })
    })
})