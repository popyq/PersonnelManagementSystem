$(function () {

    // 新增部门
    var addDepartmentUrl = '/department/insertDepartment'
    // 查看部门详情
    var queryDepartmentUrl = '/department/queryDepartmentById'
    // 修改部门信息url
    var editDepartmentUrl = '/department/editDepartmentById'

    var dep_id = getQueryParam('depId')
    console.log("dep_id"+dep_id)
    var is_edit = getQueryParam("edit")

    // 如果能从url获取到dep_id,name 那么说明用户要么在进行查看,要么在进行编辑
    if (dep_id){
        // 需要从后端获取对应的部门信息,并填充到页面上
        // 这个也是ajax请求 只不过直接指定post请求
        $.post(queryDepartmentUrl,{departmentId:dep_id},function (data) {
            // console.log(data)
            if (data.success){
                var department =data.data;
                $('#dep-name').val(department.name)
                $('#dep-address').val(department.address)
                if (department.status === 1){
                    $('#status-on').attr('checked',true)
                    $('#status-off').removeAttr('checked')
                }else{
                    $('#status-off').attr('checked',true)
                    $('#status-on').removeAttr('checked')
                }
            }
        })
    }

    $('#status-on').click(function () {
        console.log('启用按钮被点击了~')
        $('#status-on').attr('checked',true)
        $('#status-off').removeAttr('checked')
    })

    $('#status-off').click(function () {
        console.log('禁用按钮被点击了~')
        $('#status-off').attr('checked',true)
        $('#status-on').removeAttr('checked')
    })

    $("#submit").click(function(){
        var department = {}
        // 需要名称,地址,状态
        department.name = $('#dep-name').val();
        department.address = $('#dep-address').val();
        department.status = $('input[name="status"][checked]').val()
        if (is_edit){
            department.depId = dep_id
        }
        var formData = new FormData();
        // 之前学的表单数据提交可以理解成键值对  key(input标签的name属性),value就是input框的值
        formData.append("departmentStr",JSON.stringify(department))
        $.ajax({
            url:is_edit ? editDepartmentUrl : addDepartmentUrl,
            type:'post',
            dataType:'json',
            cache : false,
            contentType:false,
            // processData: false,表示会不会序列化data里面的数据,默认是true
            processData: false,
            data:formData,
            success:function(data){
                console.log(data)
                if (data.success) {
                    lightyear.notify('操作成功~', 'success', 500, 'mdi mdi-emoticon-happy', 'top', 'center','/department/toList');
                }else {
                    lightyear.notify(data.errMsg, 'danger', 500, 'mdi mdi-emoticon-sad', 'top', 'center');
                }
            }
        })
    })
})