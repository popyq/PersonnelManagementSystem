$(function () {
    $('#log-out').click(function() {
        // 为了清空Session
        $.ajax({
            url:'/logout',
            type:'post',
            async:false,
            cache:false,
            dataType:'json',
            success : function(data) {
                if (data.success) {
                    window.location.href = '/login'
                }
            },
            error : function(data,error) {
                alert(error)
            }
        })
    })
})