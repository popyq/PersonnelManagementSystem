$(function(){

    // 定义渲染列表时的条件
    var request_condition = {}

    // 是否要初始化分页插件
    var flag =true

    $('.search-bar .dropdown-menu a').click(function() {
        var field = $(this).data('field') || '';
        $('#search-field').val(field);
        $('#search-btn').html($(this).text() + ' <span class="caret"></span>');
    });

    // 监听某个键盘下的事件
    $('#search-input').keydown(function (e) {
        // console.log("按下的键对应的ascii码为: "+e.keyCode)
        // 过滤查询可能会是分页信息变化,所以初始化分页插件
        flag =true;
        request_condition.current =1
        // 13 代表回车键
        if (e.keyCode === 13) {
            var type = $('#search-field').val()
            // console.log("type为:"+type)
            var keyword = $('#search-input').val();
            if ('name' === type){
                request_condition.name= keyword
                request_condition.address= null
                getList(request_condition)
            }else {
                request_condition.address = keyword;
                request_condition.name = null;
                getList(request_condition)
            }
        }
    })

    $('#status-switch').change(function() {
        console.log("状态筛选switch被触发")
        console.log("当前switch状态为:"+$('#status-switch').is(':checked'));
        // 筛选状态,重新渲染列表之前,让分页插件具备可以再次初始化的能力, 即flag = true
        flag =true;
        request_condition.current =1
        if ($('#status-switch').is(':checked')) {
            request_condition.status = 1
            getList(request_condition)
        }else {
            request_condition.status = null
            getList(request_condition)
        }
    })

    // 初始化列表
    getList(request_condition)

    // 获取部门列表
    function getList(data) {
        console.log("进入getList()方法了")
        $.ajax({
            // url: 请求路径
            url:"/department/getList",
            // type:http的方法
            type:'post',
            // 设置同不同步
            async:false,
            // 加不加缓存
            cache:false,
            // 接收的数据类型
            datatype: 'json',
            // 发送的数类型
            contentType:'application/json;charset=utf-8',
            data:JSON.stringify(data),
            success:function(data) {
                if (data.success){
                    // 如果成功,肯定能得到列表数据,所以接下来进行动态渲染
                    console.log("部门列表回调函数成功了~")
                    if (data.data.records.length === 0  ) {
                        lightyear.notify('啥也没有搜索到 !', 'danger', 500, 'mdi mdi-emoticon-sad', 'top', 'center' );
                    }
                    // 初始化分页插件
                    if(flag){
                        getPageInfo(data.data);
                        flag=false
                    }
                    // 如果成功,肯定能得到列表数据,所以接下来进行动态渲染
                    handleList(data.data.records)
                }else {
                    // TODD: 提醒
                    lightyear.notify(data.errMsg, 'danger', 500, 'mdi mdi-emoticon-sad', 'top', 'center' );
                }
            }
        })
    }

    // 对列表数据进行渲染
    function handleList(data) {
        console.log(data)
        var i = 1
        var html = ''
        data.map(function (item,index) {
            console.log(item.depId)
            html +=  '<tr>'
                +        '<td>'+(i++)+'</td>'
                +        '<td>'+item.name+'</td>'
                +        '<td>'+item.address+'</td>'
                +            departmentStuts(item.status)
                +        '<td>'
                +            '<div class="btn-group">'
                +                '<a class="btn btn-xs btn-default"  href="/department/goDepartmentEdit?edit=true&depId= '+(item.depId)+ '" title="编辑" data-toggle="tooltip"><i class="mdi mdi-pencil"></i></a>'
                +                '<a class="btn btn-xs btn-default" href="/department/goDepartment?depId= '+(item.depId)+' " title="查看" data-toggle="tooltip"><i class="mdi mdi-eye"></i></a>'
                +                updateDepartmentStatus(item.depId,item.status)
                +            '</div>'
                +        '</td>'
                +   '</tr>'
        })
        // 渲染
        $('.department-wrap').html(html)
    }
    // 部门状态文字化处理
    function departmentStuts(status){
        // === 既比类型 又比值
        if (status === 1) {
            return '<td><font class="text-success">有效</font></td>'
        }
        return '<td><font class="text-danger">失效</font></td>'
    }

    // 修改状态图标处理
    function updateDepartmentStatus(depId,status){
        if (status === 1){
            return '<a class="btn btn-xs btn-default department-status-btn" href="#!" title="修改状态" data-id='+depId+' data-status='+status+'  data-toggle="tooltip"><i class="mdi mdi-toggle-switch"></i></a>'
        }
        return '<a class="btn btn-xs btn-default department-status-btn" href="#!" title="修改状态"  data-id='+depId+' data-status='+status+'  data-toggle="tooltip"><i class="mdi mdi-toggle-switch-off"></i></a>'
    }
    // 对列表中的所有的a标签添加点击事件,同时定位到class 为department-status-btn的a标签
    $('.department-wrap').click().on('click','a',function(e) {
        // console.log(e.currentTarget.dataset());
        var target = $(e.currentTarget);
        if(target.hasClass('department-status-btn')){
            console.log("定位到了修改的a标签")
            var depId = e.currentTarget.dataset.id
            var status = e.currentTarget.dataset.status
            if (request_condition.status === 1 ){
                flag = true
                request_condition.current = 1
            }
            $.ajax({
                url:'/department/toggleDepartment',
                type:'post',
                cache:false,
                async : true,
                dataType:'json',
                contentType:'application/json;charset=utf-8',
                data:JSON.stringify({depId : depId,status : status}),
                success:function (data) {
                    if( data.success ){
                        console.log('修改状态回调函数')
                        lightyear.notify('修改状态成功~','success', 500, 'mdi mdi-emoticon-happy', 'top', 'center' );
                        getList(request_condition)
                    }else{
                        lightyear.notify('修改状态失败!','danger', 500, 'mdi mdi-emoticon-sad', 'top', 'center' );
                        getList(request_condition)
                    }
                }
            })
        }
    })


    // 获取分页信息
    function getPageInfo(data) {
        // 初始化分页插件
        console.log("分页插件中的data:"+data)
        $('#jq-page').pagination({
             pageCount : data.pages,
            coping : true,
            // 触发分页插件上的按钮事件
            callback:function(e) {
                 // 获取到用户当前点击到的页数,并作为参数传给getList
                console.log("获取到用户当前点击到的页数:"+e.getCurrent())
                console.log("获取总页数:"+e.getPageCount())
                request_condition.current = e.getCurrent()
                 getList(request_condition)
            }
        })
    }
})
