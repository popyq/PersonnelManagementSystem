$(function () {

    // 登录验证的url
    var loginUrl = '/checkLogin';
    // 失败次数的变量
    var loginCount = 0;

    $('#submit').click(function() {
        // 获取用户输入的用户名
        var username = $('#username').val();
        // 获取用户输入的密码
        var password = $('#password').val();
        // 获取用户输入的验证码
        var captchaCode =$('#j_captcha').val();
        // 是否需要验证
        var needVerify = false
        // 如果失败三次提示输入验证码
        if (loginCount >= 3) {
            // 而且输入的验证码为null
            if (!captchaCode) {
                lightyear.notify('请输入验证码', 'danger', 1000, 'mdi mdi-emoticon-sad', 'top', 'center' );
                return;
            }else {
                needVerify = true;
            }
        }
        // 将用户输入的数据传给后台做效验
        $.ajax({
            // url: 请求路径
            url:loginUrl,
            // type:http的方法
            type:'post',
            // 设置同不同步
            async:false,
            // 加不加缓存
            cache:false,
            // 接收的数据类型
            datatype: 'json',
            // 发送的数类型
            contentType:'application/json;charset=utf-8',
            // 把对象变成一个json字符串
            data:JSON.stringify({
                userName:username,
                password:password,
                needVerify:needVerify,
                verifyCodeActual:captchaCode
            }),

            // 回调函数  成功了就触发
            success:function (data){
                console.log(data)
                if (data.success){
                    // 登录成功
                    lightyear.notify('登录成功,欢迎'+data.username, 'success', 1000, 'mdi mdi-emoticon-happy', 'top', 'center','/main' );
                }else {
                    // 登录失败了
                    lightyear.notify(data.errMsg, 'danger', 1000, 'mdi mdi-emoticon-sad', 'top', 'center' );
                    loginCount++;
                    // 如果失败次数大于3次就显示验证码
                    if (loginCount >= 3) {
                        $('#verifyPart').show();
                        // 登录失败之后自动刷新验证码
                        $('#captcha').click();
                    }
                }
            }
        })
    })
})

function changeVerifyCode(img) {
    img.src = "/Kaptcha?"+Math.floor(Math.random()*100)
}