$(function () {

    // 新增员工
    var addEmployeeUrl = '/employee/insertEmployee'
    // 查看员工详情
    var queryEmployeeUrl = '/employee/queryEmployeeById'
    // 修改员工信息url
    var editEmployeeUrl = '/employee/editEmployeeById'

    // 获取所有有效的部门列表URL
    var queryActiveDepartmentListUrl = '/department/queryActiveDepartmentList'
    // 获取所有有效的职位列表URL
    var queryActivePositionListUrl = '/position/queryActivePositionList'

    // 获取员工信息
    var employee_id = getQueryParam('emId')
    var is_edit = getQueryParam('edit')


    if (employee_id){
        $.post(queryEmployeeUrl,{employeeId:employee_id},function (data) {
            console.log("员工信息为:"+data)
            if (data.success) {
                var  employee =  data.data.employee
                $('#employee-name').val(employee.name)
                $('#employee-loginName').val(employee.loginName)
                // console.log(activeDepartmentList)
                // console.log(activePositionList)
                if (employee.status ===1) {
                    $('#status-on').attr('checked',true)
                    $('#status-off').removeAttr('checked')
                }else {
                    $('#status-off').attr('checked',true)
                    $('#status-on').removeAttr('checked')
                }
                // 显示所属职位名称,所属部门民称
                var depHtml = ''
                var isSelected = ''
                data.data.activeDepartmentList.map(function (item,index) {
                    isSelected = employee.depId === item.depId ? 'selected':''
                    depHtml +='<option data-value=" ' +item.depId  +' " ' +isSelected+ '>' +item.name +'</option>'
                })
                $('#department-select').html(depHtml)

                var positionHtml = ''
                data.data.activePositionList.map(function (item,index) {
                    isSelected = employee.positionId === item.positionId ? 'selected':''
                    positionHtml +='<option data-value=" ' +item.positionId  +' " ' +isSelected+ '>' +item.positionName +'</option>'
                })
                $('#position-select').html(positionHtml)
            }
        })
    }else {

        // 获取部门下拉列表
        $.post(queryActiveDepartmentListUrl,function (data) {
            console.log(data)
            if (data.success) {
                var activeDepartmentList = data.data
                var optionHtml = '<option data-value="">全部部门</option>'
                activeDepartmentList.map(function(item,index) {
                    optionHtml +=' <option data-value="'
                        +  item.depId +'">'
                        +  item.name+'</option>'
                })

                $('#department-select').html(optionHtml)
            }
        })

        // 获取职位下拉列表
        $.post(queryActivePositionListUrl,function (data) {
            console.log(data)
            if (data.success) {
                var activePositionList = data.data
                var optionHtml = '<option data-value="">全部职位</option>'
                activePositionList.map(function(item,index) {
                    optionHtml +=' <option data-value="'
                        +  item.positionId +'">'
                        +  item.positionName+'</option>'
                })
                $('#position-select').html(optionHtml)
            }
        })
    }





    $('#status-on').click(function () {
        console.log('启用按钮被点击了~')
        $('#status-on').attr('checked',true)
        $('#status-off').removeAttr('checked')
    })

    $('#status-off').click(function () {
        console.log('禁用按钮被点击了~')
        $('#status-off').attr('checked',true)
        $('#status-on').removeAttr('checked')
    })


    $("#submit").click(function(){
        var employee = {}
        // 需要名称,地址,状态
        employee.name = $('#employee-name').val();
        employee.loginName = $('#login-name').val();
        // employee.status = $('#status').val();
        employee.status = $('input[name="status"][checked]').val()
        employee.positionId = $('#position-select').find('option').not(
            function () {
                return !this.selected
            }
        ).data("value")

        employee.depId = $('#department-select').find('option').not(
            function () {
                return !this.selected
            }
        ).data("value")
        if (is_edit){
            employee.emId = employee_id
        }
         var formData =  new FormData();
        formData.append("employeeStr",JSON.stringify(employee))
        $.ajax({
            url:is_edit ? editEmployeeUrl : addEmployeeUrl,
            type:'post',
            dataType:'json',
            cache : false,
            contentType:false,
            // processData: false,表示会不会序列化data里面的数据,默认是true
            processData: false,
            data:formData,
            success:function(data){
                console.log(data)
                if (data.success) {
                    lightyear.notify('操作成功~', 'success', 500, 'mdi mdi-emoticon-happy', 'top', 'center','/employee/toList');
                }else {
                    lightyear.notify(data.errMsg, 'danger', 500, 'mdi mdi-emoticon-sad', 'top', 'center');
                }
            }
        })
    })
})